<template>	<!-- 2发现好茶 home组件 -->
	<div class='homefx'>
		<img src="img/zp_ziyin_n.jpg" alt="">
		<img src="img/zp_songli_n.jpg" alt="">
		<img src="" alt="">
	</div>
</template>

<script>
	export default {
		data() {
			return {
				
			};
		}
	}
</script>

<style>
 .homefx{
	 margin-top:.2rem;
	 background: #fff;
	 padding:.2rem;
 }
 .homefx img{
	 width:3.5rem;
 }
 .homefx img:first-child{
	 margin-right:.1rem;
 }
</style>
